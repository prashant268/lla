import streamlit as st
from streamlit_chat import message
from PIL import Image
import utils as utils



# Initialize counter for unique form keys
form_counter = 0

def initialize_session_state():
    """
    Initialize session state variables.
    """
    st.session_state.setdefault('history', [])
    st.session_state.setdefault('generated', ["Hello! I am here to provide answers to questions fetched from Database."])
    st.session_state.setdefault('past', ["Hello Buddy!"])
    st.session_state.setdefault('button_pressed', False)  # Add button_pressed to session state

def display_chat(conversation_chain, chain):
    """
    Display chat interface.
    """
    global form_counter  # Use global variable to track form keys
    reply_container = st.container()
    container = st.container()

    with container:
        form_counter += 1  # Increment counter for each form
        form_key = f'chat_form_{form_counter}'  # Generate unique form key
        input_key = f'input_{form_counter}'  # Generate unique input key
        with st.form(key=form_key):
            user_input = st.text_input("Question:", placeholder="Ask me questions on invoice and tables", key=input_key)
            submit_button = st.form_submit_button(label='Send ⬆️')

        if submit_button and user_input:
            generate_response(user_input, conversation_chain, chain)
    
    display_generated_responses(reply_container)

def generate_response(user_input, conversation_chain, chain):
    """
    Generate response based on user input.
    """
    if "@data" in user_input:
        # process_data_function(user_input.replace("@data", ""))  # Remove "@da
        # ta" before calling function
        with st.spinner('entered in sql mode...'):
            output = conversation_chat(user_input, conversation_chain, chain, st.session_state['history'])
            st.session_state['past'].append(user_input)
            st.session_state['generated'].append(output)
    else:
        with st.spinner('entered in document...'):
           output =  utils.user_input_chat(user_input)
           st.session_state['past'].append(user_input)
           st.session_state['generated'].append(output)

        

def conversation_chat(user_input, conversation_chain, chain, history):
    """
    Generate LLM response based on user input.
    """
    response = conversation_chain.invoke(user_input)
    final_response = chain.invoke(f"Based on the following information generate human redable response: {response['query']},  {response['result']}")

    history.append((user_input, final_response))
    return final_response

def display_generated_responses(reply_container):
    """
    Display generated responses.
    """
    if st.session_state['generated']:
        with reply_container:
            for i in range(len(st.session_state['generated'])):
                message(st.session_state["past"][i], is_user=True, key=f"{i}_user", avatar_style="adventurer")
                message(st.session_state["generated"][i], key=str(i), avatar_style="bottts")

def process_data_function(input_data):
    """
    Process data when button is pressed.
    """
    # invoice=utils.fetch_invoice()
    utils.run_query()

    st.write(f"Data Processing completed:")
    #a
    st.session_state['button_pressed'] = True  # Set button_pressed to True when button is pressed

def main():
    """
    Main function to run the Streamlit app.
    """
    initialize_session_state()
    
    st.title("AXON")

    image = Image.open('chatbot.jpg')
    st.image(image, width=150)
    
    hide_streamlit_style = """
            <style>
            #MainMenu {visibility: hidden;}
            footer {visibility: hidden;}
            </style>

            """
    st.markdown(hide_streamlit_style, unsafe_allow_html=True) 

    conversation_chain, chain = utils.create_conversational_chain()

    button_pressed = st.button("Process Data")

    if button_pressed and not st.session_state['button_pressed']:  # Check if button is pressed and button_pressed is False
        process_data_function("Some input data")  # Modify input data as per your requirements

    display_chat(conversation_chain, chain)

if __name__ == "__main__":
    main()
