from langchain_community.utilities import SQLDatabase

from langchain_core.prompts import PromptTemplate

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_experimental.sql.base import SQLDatabaseChain
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_community.utilities import SQLDatabase
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory
from math import acos,cos,sin, radians
import configparser
import pandas as pd
import psycopg2
import os
from langchain_google_genai import GoogleGenerativeAIEmbeddings
import google.generativeai as genai
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
import retrying

def read_properties_file(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"The file '{file_path}' does not exist.")
    config = configparser.ConfigParser()

    config.read(file_path)

    db_path = config['DEFAULT']['db_path']
    gemini_api_key = config['DEFAULT']['gemini_api_key']
    
    return db_path, gemini_api_key

def get_property():
    file_path = 'config.properties'

    try:
        db_path, gemini_api_key = read_properties_file(file_path)
        print("Database path:", db_path)
        print("Gemini API Key", gemini_api_key)
        return db_path, gemini_api_key
    except FileNotFoundError as e:
        print(e)
        raise e
    
def get_llm(gemini_api_key):
    # Create llm
    llm = ChatGoogleGenerativeAI(model="gemini-pro", google_api_key=gemini_api_key, 
                                 convert_system_message_to_human=True, temperature=0.0)
    return llm

def db_connection(db_path):
    db = SQLDatabase.from_uri(f"sqlite:///{db_path}")
    print(db.dialect)
    print(db.get_usable_table_names())
    # resp = db.run("SELECT * FROM 'yola_salesorder' LIMIT 1;")
    # print(resp)
    return db

def create_conversational_chain():
    try:
        db, gemini_api_key = get_property()
        llm = get_llm(gemini_api_key) 
        db = db_connection(db)
        sql_prompt_template = """ 
          
        You work for a logistics company that handles invoicing and delivery operations for various products. 
        Your company maintains three database tables: "invoice","delivery" and "customers".
            it has a two tables  
            1.invoice which has column names as following:
            ['invoiceno-invoice id 
            'sales_order_no'-it is sales order number
            'amount' it is the price of items,currency type is M.A.D
            'invoicedate' date of invoice
            'itemname'-item name
            'plant'-delivery plant number
            'quantity'-it is quantity of orders
            'net_weight'-it is net weight of orders
            'customername'-it iscustomer name
            'customerid'-unique id for each customers
            ]
            
            2 second table is delivery:
            ['date_of_delivery',
              'tripno':this is trip id number,
                'invoiceno' this is invoice id , 
                'deliveryexecutiveempcode' this is delivery executive employee code,
                'deliveryexecutivename' this is delivery executive employee name, 
                'customerid' this is customer id, 
                'out_for_delivery' this is column showing if delivery started from source or not,
                'delivery_status': this column show is item delivered or not,
                'on_time_delivery' this show if delivery status i.e late or on-time delivery
                ]

            

            Instructions:

            Our focus is on analyzing trends in delivery efficiency and performance using the provided invoice and delivery details data.
            Please refrain from generating new data or discussing topics beyond the scope of delivery efficiency analysis.
            If you encounter a question or topic not related to delivery efficiency analysis, respond with "I don't know."
            With these guidelines, let's delve into exploring insights from the provided data to optimize delivery operations and enhance efficiency.
            Question: {input}
            Given an input question, first create a syntactically correct
            {dialect} query to run.
            Relevant pieces of previous conversation:
            {history}
            
            Dont include ```, ```sql and \n in the output.
            




        """
        prompt = PromptTemplate(
                input_variables=["input", "dialect", "history"],
                template=sql_prompt_template,
            )
        memory = ConversationBufferMemory(memory_key="history")
        db_chain = SQLDatabaseChain.from_llm(
                llm, db, memory=memory, prompt=prompt, return_direct=True,  verbose=True
            )

        output_parser = StrOutputParser()
        chain = llm | output_parser
    except Exception as e:
        raise e
    return  db_chain, chain

import psycopg2
import pandas as pd
from sqlalchemy import create_engine,inspect
def run_query():
    
        # Connect to your PostgreSQL database
        connection = psycopg2.connect(
            user="datascience",
            password="`oVQ:EQh#?.YY#Rb",
            host="34.93.219.141",
            port="5432",
            database="dms"
        )

        # Create a cursor object using the connection
        cursor = connection.cursor()

        # Execute the SQL query
        # query = "SELECT date_of_delivery,salesorderno,invoiceno,sold_to_party,on_slot_delivery FROM yf_live_delivery_tracking ORDER BY date_of_delivery DESC LIMIT 10;"
        query="SELECT invoicedetails_invoiceno,invoicedetails_sales_order_no,itemsupplied_total_amount,invoicedate,itemsupplied_itemname,shipping_point,itemsupplied_quantity,cr_invoice_net_weight,customername,invoicedetails_sold_to_party FROM public.yola_invoice_items ORDER BY created_at DESC LIMIT 10"
        cursor.execute(query)
        rows = cursor.fetchall()
        col_names = [desc[0] for desc in cursor.description]
        
        df = pd.DataFrame(rows, columns=col_names)
        query="SELECT date_of_delivery,tripno,invoiceno,deliveryexecutiveempcode,deliveryexecutivename,sold_to_party,out_for_delivery,delivery_status,otd FROM yf_live_delivery_tracking ORDER BY date_of_delivery DESC LIMIT 10"
        cursor.execute(query)
        rows = cursor.fetchall()
        col_names = [desc[0] for desc in cursor.description]
        
        df1 = pd.DataFrame(rows, columns=col_names)
        # Convert the result into a pandas DataFrame
       #

        return df,df1


db, gemini_api_key = get_property()
os.environ["GOOGLE_API_KEY"] = str(gemini_api_key)
genai.configure(api_key=os.environ.get("GOOGLE_API_KEY"))

def get_conversational_chain():  

    prompt_template = """
    Answer the question as detailed as possible from the provided context, make sure to provide all the details. 

    don't give wrong answers or made up answers by hallucination.
    
    \n\n
    Context:\n {context}?\n
    Question: \n{question}\n

    Answer:
    """
    model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0, max_tokens=300,request_timeout=3)
    prompt = PromptTemplate(template = prompt_template, input_variables = ["context", "question"])
    chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)
    return chain


def user_input_chat(user_question):
    embeddings = GoogleGenerativeAIEmbeddings(model = "models/embedding-001")
    new_db = FAISS.load_local("faiss_prod_inex", embeddings)
    docs = new_db.similarity_search(user_question)
    chain = get_conversational_chain()
    response = chain(
        {"input_documents":docs, "question": user_question}
        , return_only_outputs=True)
    #print(response)
    #st.write("Reply: ", response["output_text"])
    return response["output_text"]

   

# Call the function to run the query and save the result in a DataFrame
# invoice_df,delivery_df = run_query()
# invoice_df.columns=['invoiceno', 'sales_order_no',
#        'amount', 'invoicedate', 'itemname',
#        'plant', 'quantity', 'net_weight',
#        'customername', 'customerid']
# # Print the DataFrame
# delivery_df.columns=['date_of_delivery', 'tripno', 'invoiceno', 'deliveryexecutiveempcode',
#        'deliveryexecutivename', 'customerid', 'out_for_delivery',
#        'delivery_status', 'on_time_delivery']
# engine = create_engine('sqlite:///y_test1.db', echo=True)
# invoice_df.to_sql('invoice', con=engine, index=False, if_exists='replace')
# delivery_df.to_sql('delivery', con=engine, index=False, if_exists='replace')
    
